<?php
namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Bet;
use Illuminate\Http\Request;
use Hash;

class AdminController extends Controller {

    public function dashboard(){
        return view('admin.dashboard',[
            'users'=>User::where('role','user')->count(),
            'bets'=>Bet::count(),
            'profit'=>Bet::where('status','lose')->sum('bet_amount')
        ]);
    }

    public function users(){
        return view('admin.users',['users'=>User::where('role','user')->get()]);
    }

    public function createUser(Request $r){
        User::create([
            'name'=>$r->username,
            'username'=>$r->username,
            'password'=>Hash::make($r->password),
            'balance'=>$r->balance,
            'role'=>'user'
        ]);
        return back();
    }

    public function bets(){
        return view('admin.bets',['bets'=>Bet::latest()->get()]);
    }

    public function betResult(Request $r){
        $bet=Bet::find($r->bet_id);
        if($r->result=='win'){
            $bet->status='win';
            $bet->user->increment('balance',$bet->bet_amount*$bet->odds);
        } else {
            $bet->status='lose';
        }
        $bet->save();
        return back();
    }
}
