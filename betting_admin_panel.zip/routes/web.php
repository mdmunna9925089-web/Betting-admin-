<?php
use App\Http\Controllers\AdminController;
Route::middleware(['auth','admin'])->prefix('admin')->group(function(){
    Route::get('/dashboard',[AdminController::class,'dashboard']);
    Route::get('/users',[AdminController::class,'users']);
    Route::post('/users/create',[AdminController::class,'createUser']);
    Route::get('/bets',[AdminController::class,'bets']);
    Route::post('/bet/result',[AdminController::class,'betResult']);
});
