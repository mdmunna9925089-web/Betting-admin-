
<h3>Create User</h3>
<form method="POST" action="/admin/users/create">
@csrf
<input name="username" placeholder="Username">
<input name="password" type="password">
<input name="balance" step="0.01" placeholder="৳ Balance">
<button>Create</button>
</form>

<h3>All Users</h3>
@foreach($users as $u)
<p>{{ $u->username }} - ৳{{ $u->balance }}</p>
@endforeach
