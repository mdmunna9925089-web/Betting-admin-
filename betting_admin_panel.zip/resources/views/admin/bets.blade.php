
<h3>All Bets</h3>
<table border="1">
@foreach($bets as $b)
<tr>
<td>{{ $b->match_name }}</td>
<td>৳{{ $b->bet_amount }}</td>
<td>Odds {{ $b->odds }}</td>
<td>{{ $b->status }}</td>
<td>
@if($b->status=='pending')
<form method="POST" action="/admin/bet/result">
@csrf
<input type="hidden" name="bet_id" value="{{ $b->id }}">
<button name="result" value="win">WIN</button>
<button name="result" value="lose">LOSE</button>
</form>
@endif
</td>
</tr>
@endforeach
</table>
