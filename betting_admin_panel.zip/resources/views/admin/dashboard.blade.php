
<h2>Admin Dashboard</h2>
Users: {{ $users }} <br>
Bets: {{ $bets }} <br>
Profit: ৳{{ $profit }}
